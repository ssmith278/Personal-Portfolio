#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void getUnsortedArray(int n, double *pArr);
void *sortArray(void *arg);
void *mergeArrays(void *arg);
void printArray(int n, double *pArr);

typedef struct Sortable{

    int n;
    double *dArr;
} Sortable;

typedef struct Mergable{

    int t;
    Sortable *sorts;
} Mergable;

int main(int argc, void *argv[])
{
    int i;
    int n = atoi(argv[1]);
    int t;

    if (argc > 2)
    {
        t = atoi(argv[2]);
        if(t == 0 || n % t != 0)
        {
            fprintf(stderr, "Invalid N/T combination: %d/%d.\n"
                    "Please enter a combination where T != 0 AND N mod T == 0\n",
                    n, t);
            exit(EXIT_FAILURE);
        }
    }
    else
    {
        t = 1;
    }

    Sortable *arr = (Sortable*)malloc(sizeof(Sortable));
    if(arr == NULL)
    {
        fprintf(stderr, "Failed to malloc Sortable");
        exit(EXIT_FAILURE);
    }    
    arr->dArr = (double*)malloc(sizeof(double)*n);
    if(arr->dArr == NULL)
    {
        fprintf(stderr, "Failed to malloc dArray");
        exit(EXIT_FAILURE);
    }
    arr->n = n;
 
    getUnsortedArray(n, arr->dArr);
    
    //printf("Unsorted array: \n");
    //printArray(n, arr->dArr);

    //Split the arrays
    Sortable slices[t];
    for(i = 0; i < t; i++)
    {
        slices[i].n = n/t;
        slices[i].dArr = arr->dArr+(n/t)*i;
    }

    //Time the sorting
    clock_t start = clock();

    //Sort array slices
    pthread_t tid[t];
    for(i = 0; i < t; i++)
    {
        pthread_create(&tid[i], NULL, sortArray, (void*)&slices[i]);
    }

    for(i = 0; i < t; i++)
    {
        pthread_join(tid[i], NULL);
    }
    
    //Merge array slices
    Mergable mArr = { t, slices };
    Sortable *result; 
    pthread_t mtid;
    pthread_create(&mtid, NULL, mergeArrays, (void*)&mArr);
    pthread_join(mtid, (void**)&result);
    
    clock_t end = clock();
    
    //printf("Sorted array: \n");
    //printArray(n, ((Sortable*)result)->dArr);
    printf("\nExecution time: %f ms\n", (double)(end - start) / CLOCKS_PER_SEC * 1000);

    free(result->dArr);
    free(result);
    free(arr->dArr);
    free(arr);
    exit(EXIT_SUCCESS);
}

void getUnsortedArray(int n, double *pArr)
{
    int min = 1.0;
    int max = 1000.0;
    int i;

    srand(time(0));
    for(i = 0; i < n; i++)
    {
        pArr[i] = (rand() % max) + min;
    }
}

void *sortArray(void *arg)
{
    Sortable *tmpArr = (Sortable*)arg;
    double *dArr = tmpArr->dArr;

    //Sort
    int i, j, k;
    for(i = 1; i < tmpArr->n; i++)
    {
        k = dArr[i];
        j = i-1;

        while(j >= 0 && dArr[j] > k)
        {
            dArr[j+1] = dArr[j];
            j = j-1;
        }
        dArr[j+1] = k;
    }

    return NULL;
}


void *mergeArrays(void *arg)
{
    Mergable *mArr = (Mergable*)arg;
    int t = mArr->t;
    Sortable *slices = mArr->sorts;
    int n = slices[0].n;

    int i;
    int totalN = t*n;
    int totalIdx = 0;
    int idx[t];

    for(i = 0; i < t; i++)
    {
        idx[i] = 0;
    }

    Sortable *result = (Sortable*)malloc(sizeof(Sortable));
    result->dArr = (double *)malloc(sizeof(double) * totalN);
    double *dArr = result->dArr;

    while(totalIdx < totalN)
    {
        int minSlice = -1;
        
        //Loop through slices
        for(i = 0; i < t; i++)
        {
            //Get slice idx for min element
            if(idx[i] < n)
            {
                if(minSlice < 0) minSlice = i;
                if(slices[i].dArr[idx[i]] < slices[minSlice].dArr[idx[minSlice]])
                {
                    minSlice = i;
                }
            }
        }
        // Add minimum element to new array
        dArr[totalIdx] = slices[minSlice].dArr[idx[minSlice]];
        idx[minSlice]++;
        totalIdx++;       
    }
    
    return (void*)result;
}

void printArray(int n, double *pArr)
{
    int i;
    
    for(i = 0; i < n; i++)
    {
        if(i != 0 && i%4 == 0)
        {
            printf("\n");
        }    
        if(i ==0)
        {
            printf("\t[");
        }
        else
        {
            printf("\t");
        }

        printf("%.3f", pArr[i]);
       
        if(i == n-1)
        {
            printf("]\n");
        }
        else
        {
            printf(", ");
        }
    }
}
